﻿using System;

namespace FizzBuzz.Interfaces
{
    /// <summary>
    /// 
    /// </summary>
    public interface IObjFizzBuzz
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="length"></param>
        /// <param name="fizzNumber"></param>
        /// <param name="buzzNumber"></param>
        void FizzBuzzFunction(Int32 fizzNumber, Int32 buzzNumber, Int32 length);
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        Int32 GetFizzCount();
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        Int32 GetBuzzCount();


    }
}
