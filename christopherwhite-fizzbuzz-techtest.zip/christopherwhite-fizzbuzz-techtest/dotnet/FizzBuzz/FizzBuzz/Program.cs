﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using FizzBuzz.Classes;
using FizzBuzz.Interfaces;

namespace FizzBuzz
{
    public class Program
    {
        #region declarations

        private static String fizzNumberInput;
        private static String buzzNumberInput;
        private static String cycleInput;

        #endregion

        private static void Main(String[] args)
        {

            var yesNo = String.Empty;

            //This section could do with some error handling to ensure input is a string
            try
            {
                Console.WriteLine("Good day to you, would you like to play Fizz Buzz, Y or N ? ");
                while ((!yesNo.Contains("Y") && (yesNo.Length != 1)))
                {
                    yesNo = Console.ReadLine().ToUpper();

                    if (yesNo == "N")
                    {
                        Environment.Exit(-1);
                    }
                    else
                    {
                        break;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }


            try
            {
                //This section could do with some error trapping and handling to ensure that inputs are numbers
                if (yesNo == "Y")
                {
                    Console.WriteLine("Please provide a Fizz number");
                    fizzNumberInput = Console.ReadLine();

                    Console.WriteLine("Please provide a Buzz number");
                    buzzNumberInput = Console.ReadLine();

                    Console.WriteLine("Please enter a maximum number to count to, up to 10,000, this is optional");
                    cycleInput = Console.ReadLine();

                    IObjFizzBuzz app = new ObjFizzBuzz(Convert.ToInt32(fizzNumberInput), Convert.ToInt32(buzzNumberInput), Convert.ToInt32(cycleInput));

                    Console.WriteLine("  -------------------------- ");
                    Console.WriteLine("Your Fizz Buzz results are above, press any key to exit.");
                    Console.ReadLine();

                    Environment.Exit(-1);
                }
                else
                {
                    Environment.Exit(-1);
                }
            } // Here we would have a series of exceptions to catch all possible exception thrown by this application
            //and handled 
            catch (Exception e)
            {

                //Possible exception are 
                //1. Not a number 
                //2. Number to large for an Int 
                //3. Negative numbers 
                Console.WriteLine(e);
                throw;
            }

        }
    }
}


