﻿using System;
using FizzBuzz.Interfaces;

namespace FizzBuzz.Classes
{
    /// <summary>
    /// 
    /// </summary>
    public class ObjFizzBuzz : IObjFizzBuzz
    {

        #region variables

        private Int32 Fizz
        {
            get { return fizzcount; }
            set { fizzcount = value; }
        }

        private Int32 Buzz
        {
            get { return buzzcount; }
            set { buzzcount = value; }
        }

        private Int32 fizzcount;
        private Int32 buzzcount;
        private Int32 cyclelength;

        #endregion


        #region properties


        /// <summary>
        /// Returns the Fizz Count 
        /// </summary>
        /// <returns></returns>
        public Int32 GetFizzCount()
        {
            return Fizz;
        }

        /// <summary>
        /// Returns the Buzz Count
        /// </summary>
        /// <returns></returns>
        public Int32 GetBuzzCount()
        {
            return Buzz;
        }

        #endregion 


        /// <summary>
        /// 
        /// </summary>
        /// <param name="fizzNumber"></param>
        /// <param name="buzzNumber"></param>
        public ObjFizzBuzz(Int32 fizzNumber = 3, Int32 buzzNumber = 5)
        {
            fizzcount = 0;
            buzzcount = 0;

            Fizz = fizzNumber;
            Buzz = buzzNumber;
        
            FizzBuzzFunction(Fizz, Buzz);
        }

        /// <summary>
        /// The overload method allows you to specify the amount of times you want the cycle 
        /// to go on for.
        /// </summary>
        /// <param name="fizzNumber"></param>
        /// <param name="buzzNumber"></param>
        /// <param name="length"></param>
        public ObjFizzBuzz(Int32 fizzNumber = 3, Int32 buzzNumber = 5, Int32 length = 100)
        {
            fizzcount = 0;
            buzzcount = 0;
            cyclelength = 0;

            Fizz = fizzNumber;
            Buzz = buzzNumber;
            cyclelength = length;

            FizzBuzzFunction(Fizz, Buzz, cyclelength);
        }

        /// <summary>
        /// This function will increment from 0 to which ever "length" value is provided 
        /// and output either the word Fizz or Buzz to the output Console.
        /// </summary>
        /// <param name="length"></param>
        /// <param name="fizzNumber"></param>
        /// <param name="buzzNumber"></param>
        public void FizzBuzzFunction(Int32 fizzNumber = 3, Int32 buzzNumber = 5, Int32 length = 100)
        {

            for (var i = 1; i <= length; i++)
            {
                if ((i % fizzNumber == 0) && (i % buzzNumber == 0))
                {
                    Console.Write(" FizzBuzz ");
                    Fizz += 1;
                    Buzz += 1;
                }
                else if (i % fizzNumber == 0)
                {
                    Console.Write(" Fizz ");
                    Fizz += 1;
                }
                else if (i % buzzNumber == 0)
                {

                    Console.Write(" Buzz ");
                    Buzz += 1;
                }
            }

        }
    }
}
