﻿using System;
using FizzBuzz.Classes;
using FizzBuzz.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestFzzBuzz
{
    [TestClass]
    public class FizzBussTest
    {
        private IObjFizzBuzz fBuzz;



        /// <summary>
        /// Test to determine if the amount of times Fizz or Buzz shown 
        /// </summary>
        [TestMethod]
        public void Test_FizzBuzzCount()
        {
            const Int32 fizzamount = -3;
            const Int32 buzzamount = 5;

            fBuzz = new ObjFizzBuzz(fizzamount, buzzamount);

            var bCount = fBuzz.GetBuzzCount();
            var fCount = fBuzz.GetFizzCount();

            Assert.IsNotNull(bCount);
            Assert.IsNotNull(fCount);

            Assert.AreNotEqual(bCount, buzzamount / 100);
            Assert.AreNotEqual(fCount, fizzamount / 100);


        }


        /// <summary>
        /// 
        /// </summary>
        [TestMethod]
        public void Test_FizzBuzzReturnType()
        {
            const Int32 fizzamount = 3;
            const Int32 buzzamount = 5;

            fBuzz = new ObjFizzBuzz(fizzamount, buzzamount);

            var bCount = fBuzz.GetBuzzCount();
            var fCount = fBuzz.GetFizzCount();

            Assert.AreEqual(typeof(Int32), bCount.GetType());
            Assert.AreEqual(typeof(Int32), fCount.GetType());

          }
    }
}
